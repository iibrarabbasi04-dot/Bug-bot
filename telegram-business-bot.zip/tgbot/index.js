// Telegram + WhatsApp Business Auto Message Bot
// Baileys se aapka apna business WhatsApp number ek baar pair hota hai,
// phir Telegram se number do ya sticker bhejo to business message chala jata hai.

require('dotenv').config();
const { Telegraf } = require('telegraf');
const pino = require('pino');
const fs = require('fs');
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require('@whiskeysockets/baileys');

const BOT_TOKEN = process.env.BOT_TOKEN;
const OWNER_ID = String(process.env.OWNER_ID || '');
const SETTINGS_FILE = './settings.json';

if (!BOT_TOKEN || !OWNER_ID) {
  console.error('BOT_TOKEN aur OWNER_ID .env ya Render environment mein daalna zaroori hai.');
  process.exit(1);
}

// ---------- Settings (message aur last number yaad rakhne ke liye) ----------
let settings = {
  message: 'Assalam o Alaikum! Hamari dukaan se rabta karne ka shukriya. Order ya rate ke liye reply karein.',
  lastNumber: '',
};
try {
  if (fs.existsSync(SETTINGS_FILE)) {
    settings = { ...settings, ...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) };
  }
} catch (e) {
  console.log('settings parhne mein masla:', e.message);
}
const saveSettings = () => fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));

// ---------- WhatsApp (Baileys) ----------
let sock = null;
let waReady = false;
let pairingNumber = null; // jis number ko pair karna hai

async function startWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState('./wa_session');
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: 'silent' }),
    printQRInTerminal: false,
    browser: ['Business Bot', 'Chrome', '1.0.0'],
  });

  sock.ev.on('creds.update', saveCreds);

  // Agar abhi pair nahi hua aur number diya hua hai to pairing code maango
  if (!sock.authState.creds.registered && pairingNumber) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(pairingNumber);
        await bot.telegram.sendMessage(
          OWNER_ID,
          `Pairing code: ${code}\n\nWhatsApp > Linked Devices > Link with phone number > yeh code daalein.`
        );
      } catch (e) {
        await bot.telegram.sendMessage(OWNER_ID, 'Pairing code nahi ban saka: ' + e.message);
      }
    }, 3000);
  }

  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      waReady = true;
      bot.telegram.sendMessage(OWNER_ID, 'WhatsApp connect ho gaya. Ab number bhej sakte hain.').catch(() => {});
    }
    if (connection === 'close') {
      waReady = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code === DisconnectReason.loggedOut) {
        fs.rmSync('./wa_session', { recursive: true, force: true });
        bot.telegram.sendMessage(OWNER_ID, 'WhatsApp logout ho gaya. Dobara /pair 92300xxxxxxx karein.').catch(() => {});
      } else {
        setTimeout(startWhatsApp, 3000);
      }
    }
  });
}

// "0300-1234567" ya "+92 300 1234567" ko 923001234567 mein badalna
function cleanNumber(input) {
  let n = String(input).replace(/\D/g, '');
  if (n.startsWith('00')) n = n.slice(2);
  if (n.startsWith('0')) n = '92' + n.slice(1);
  return n;
}

async function sendBusinessMessage(number) {
  if (!waReady) throw new Error('WhatsApp abhi connect nahi hai. Pehle /pair karein.');
  const clean = cleanNumber(number);
  if (clean.length < 10 || clean.length > 15) throw new Error('Number ghalat lag raha hai.');

  const [exists] = await sock.onWhatsApp(clean + '@s.whatsapp.net');
  if (!exists || !exists.exists) throw new Error('Is number par WhatsApp nahi hai.');

  await sock.sendMessage(exists.jid, { text: settings.message });
  settings.lastNumber = clean;
  saveSettings();
  return clean;
}

// ---------- Telegram ----------
const bot = new Telegraf(BOT_TOKEN);

// Sirf owner use kar sakta hai
bot.use((ctx, next) => {
  if (String(ctx.from?.id) !== OWNER_ID) return ctx.reply('Yeh bot sirf owner ke liye hai.');
  return next();
});

bot.start((ctx) =>
  ctx.reply(
    'Business Bot\n\n' +
      '/pair 92300xxxxxxx - apna business WhatsApp number ek baar pair karein\n' +
      '/send 92300xxxxxxx - is number par business message bhejein\n' +
      '/setmsg text - business message badlein\n' +
      '/msg - maujooda message dekhein\n' +
      '/status - WhatsApp ka status\n\n' +
      'Sticker bhejein to last number par business message chala jayega.\n' +
      'Seedha number bhejein to bhi message chala jayega.'
  )
);

bot.command('pair', async (ctx) => {
  const num = cleanNumber(ctx.message.text.split(' ').slice(1).join(''));
  if (!num) return ctx.reply('Aise likhein: /pair 923001234567');
  if (waReady) return ctx.reply('WhatsApp pehle se connect hai.');
  pairingNumber = num;
  await ctx.reply('Pairing code bana raha hoon, thori der intezar karein...');
  if (sock) {
    try { sock.end(); } catch (_) {}
  }
  startWhatsApp();
});

bot.command('send', async (ctx) => {
  const num = ctx.message.text.split(' ').slice(1).join('');
  if (!num) return ctx.reply('Aise likhein: /send 923001234567');
  try {
    const sent = await sendBusinessMessage(num);
    ctx.reply('Message chala gaya: ' + sent);
  } catch (e) {
    ctx.reply('Masla: ' + e.message);
  }
});

bot.command('setmsg', (ctx) => {
  const text = ctx.message.text.split(' ').slice(1).join(' ').trim();
  if (!text) return ctx.reply('Aise likhein: /setmsg aapka business message');
  settings.message = text;
  saveSettings();
  ctx.reply('Business message save ho gaya.');
});

bot.command('msg', (ctx) => ctx.reply('Maujooda message:\n\n' + settings.message));

bot.command('status', (ctx) =>
  ctx.reply(`WhatsApp: ${waReady ? 'connected' : 'connected nahi'}\nLast number: ${settings.lastNumber || 'koi nahi'}`)
);

// Sticker bhejne par last number par business message
bot.on('sticker', async (ctx) => {
  if (!settings.lastNumber) return ctx.reply('Pehle /send ya koi number bhejein, phir sticker kaam karega.');
  try {
    const sent = await sendBusinessMessage(settings.lastNumber);
    ctx.reply('Sticker command: message chala gaya ' + sent);
  } catch (e) {
    ctx.reply('Masla: ' + e.message);
  }
});

// Sirf number likh kar bhejein to bhi message chala jaye
bot.on('text', async (ctx) => {
  const text = ctx.message.text.trim();
  if (text.startsWith('/')) return;
  if (!/^[+\d\s-]{10,16}$/.test(text)) return ctx.reply('Number bhejein ya /start dekhein.');
  try {
    const sent = await sendBusinessMessage(text);
    ctx.reply('Message chala gaya: ' + sent);
  } catch (e) {
    ctx.reply('Masla: ' + e.message);
  }
});

bot.launch().then(() => console.log('Telegram bot chal gaya'));
// Agar pehle se session saved hai to WhatsApp khud connect ho jaye
if (fs.existsSync('./wa_session')) startWhatsApp();

// Render Web Service ko ek port chahiye hota hai, warna deploy fail ho jata hai.
// Yeh chhota server sirf "bot zinda hai" dikhata hai (uptime ping ke liye bhi kaam aata hai).
require('http')
  .createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Bot chal raha hai');
  })
  .listen(process.env.PORT || 3000);

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
