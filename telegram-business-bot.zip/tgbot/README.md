# Telegram WhatsApp Business Bot

Telegram se apne business WhatsApp number ke zariye kisi bhi number par auto message bhejne wala bot.

## Setup

1. Telegram par @BotFather se naya bot banayein aur token copy karein.
2. Apni Telegram numeric ID @userinfobot se maloom karein.
3. `.env.example` ko `.env` naam se copy karein aur token aur ID daalein.
4. `npm install` phir `npm start`.

## Render par chalana

- GitHub repo mein yeh sari files upload karein.
- Render par New > Web Service ya Background Worker, repo connect karein.
- Build command: `npm install`
- Start command: `npm start`
- Environment mein `BOT_TOKEN` aur `OWNER_ID` daalein.

Zaroori: Render par `wa_session` folder restart par mit sakta hai. Persistent disk lagayein (mount path `/opt/render/project/src/wa_session`) warna har restart par dobara pair karna parega.

## Commands

- `/pair 923001234567` apna business WhatsApp number ek baar pair karein, bot pairing code dega
- `/send 923001234567` us number par business message bhejein
- `/setmsg text` business message badlein
- `/msg` maujooda message
- `/status` WhatsApp ka status
- Sticker bhejein: last number par business message chala jayega
- Sirf number likh dein to bhi message chala jayega

## Dhyan rakhein

- Apne business number ko ek baar pair karna zaroori hai, yeh WhatsApp ki security hai. Pairing ke baad sirf number daalne se message jata hai.
- Sirf unhein message bhejein jo aap se rabta karna chahte hain. Unknown logon ko bulk message karne se WhatsApp number ban kar sakta hai.
